/*
Q2.
Poster Perimeter
Chef wants to print out a poster on a rectangular piece of paper.
The piece of paper he uses cannot be too large,
or his printer will be unable to handle it.Specifically, the length of the rectangle must be an integer between 1 1 and N N units, and the width must be an integer between 1 1 and M M units.
Chef would like it if the perimeter of the paper is as close to K K as possible.If Chef chooses the paper 's dimensions optimally, find the minimum possible difference between the paper' s perimeter and K K.
Recall that the perimeter of a rectangle with length l l and width w w equals 2
⋅ (l + w)2⋅(l + w).
Input Format The first line of input will contain a single integer T T,
denoting the number of test cases.The first and only line of input will contain three space - separated integers
N,M,N, M, and K K —— the maximum allowed length and width, and the target perimeter.Output Format For each test case, output on a new line the minimum possible difference between the paper's perimeter and  K K.
Constraints
1≤ T≤ 100
1≤T≤100
1≤ N,M,K≤ 100
1≤N, M, K≤100
Sample 1:
Input
Output 4 5 5 12 3 4 5 2 1 9 34 45 1 0 1 3 3 Explanation : Test case 1 1:
The target perimeter is 12 12, and the maximum allowed length and width are both 5 5. Chef can choose a length of 2 2 and a width of 4 4, leading to a perimeter of 2⋅ (2 + 4) = 12 2⋅(2 + 4) = 12. So, the minimum difference from 12 12 is 0 0.
Test case 2 2: The target perimeter is 55. It can be shown that attaining a perimeter of exactly 55 is impossible, but it's possible to reach 66 instead (with length 11 and width 22, for example), which is only 11 away from the target.

Test case
33:The optimal perimeter is 6 6, obtained by choosing length 2 2 and width 1 1. This has a difference of
∣ 6− 9∣ = 3
∣6−9∣ = 3 away from the target, which is the best we can do.

Test case 4 4:
Choosing
l =
w =1 l = w = 1 gives a perimeter of 2⋅ (1 +1) =4 2⋅(1 + 1) = 4,
which is the closest Chef can get to his target of 1 1. The difference is
∣ 1− 4∣ =3
∣1−4∣ = 3.

*/

#include <iostream>
#include <cmath>
#include <climits>
using namespace std;

int main()
{
    int T;
    cin >> T;

    while (T--)
    {
        int N, M, K;
        cin >> N >> M >> K;

        int min_diff = INT_MAX;

        for (int l = 1; l <= N; ++l)
        {
            for (int w = 1; w <= M; ++w)
            {
                int perimeter = 2 * (l + w);
                int diff = abs(perimeter - K);
                min_diff = min(min_diff, diff);
            }
        }

        cout << min_diff << endl;
    }

    return 0;
}