/*
Q3.
Stable Array
You're given an array A
A of length NN.Every second, the following process will happen:
For each i
i from 11 to
N−1
N−1 in order, if
Ai<Ai+1A
i<A
i+1, set
Ai
Aito
Ai+1A i+1.
For example, if
A=[3,1,4,1,5]
A=[3,1,4,1,5], the process is as follows:
A1
A1 is not less than
A2
A 2, so it won't change.
A2
A 2 is less than
A3
A 3, so
A2
A 2 will be set to
A3=4
A3=4.
A3
A 3is not less than
A4
A 4, so it won't change.
A4
A 4 is less than
A5
A 5, so it will be set to
A5=5
A 5=5.
The array after the changes is
[3,4,4,5,5]
[3,4,4,5,5].
A is said to be stable if none of its elements change after the process.
How many seconds will it take for A
A to become stable?
Input Format
The first line of input will contain a single integer T
T, denoting the number of test cases.
Each test case consists of two lines of input.
The first line of each test case contains a single integer N
N — the length of the array.
The second line contains N
N space-separated integers
A1,A2,…,AN
Output Format
For each test case, output on a new line the number of seconds after which A
A becomes stable.
Constraints
1≤T≤105
1≤T≤105
1≤N≤3⋅105
1≤N≤3⋅10 5

1≤Ai≤N1≤A
i≤N
The sum of N
N over all test cases won't exceed 3⋅105
3⋅105.
Sample 1:
Input
Output 4 3 3 2 1 3 1 2 3 4 2 1 3 1 5 3 1 4 1 5 0 2 2 4 Explanation : Test case 1 1:
The array is already stable.
    Test case 2 2:
The array changes to
[2,3,3]
[2, 3, 3] after one second,and
[3,3,3]
[3, 3, 3] after another second.This array is stable.

Test case 3 3:
The changes are
[2,1,3,1]→[2,3,3,1]→[3,3,3,1]
[2, 1, 3, 1]→[2, 3, 3, 1]→[3, 3, 3, 1],
the last of which is stable.

*/

#include <iostream>
#include <vector>
using namespace std;

int stable_array_time(int N, vector<int> &A)
{
    int seconds = 0;
    bool changed = true;

    while (changed)
    {
        changed = false;
        int max_val = A[0];
        for (int i = 1; i < N; ++i)
        {
            if (A[i - 1] < A[i])
            {
                A[i - 1] = A[i];
                changed = true;
            }
            max_val = max(max_val, A[i]);
        }
        if (changed)
        {
            ++seconds;
        }
    }

    return seconds;
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int T;
    cin >> T;
    while (T--)
    {
        int N;
        cin >> N;
        vector<int> A(N);
        for (int i = 0; i < N; ++i)
        {
            cin >> A[i];
        }
        cout << stable_array_time(N, A) << '\n';
    }

    return 0;
}