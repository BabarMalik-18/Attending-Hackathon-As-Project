#include <iostream>
#include <utility>
using namespace std;

pair<long long, long long> findCoordinates(long long N)
{
    long long level = 1; // Start at the first level
    long long count = 1; // First house is at level 1

    // Find the level where the address N resides
    while (true)
    {
        long long housesOnLevel = 4 * level; // Number of houses on the current level
        if (count + housesOnLevel >= N)
            break;
        count += housesOnLevel; // Move to the next level
        level++;
    }

    // Calculate the remaining position in the level
    long long remaining = N - count;

    // Determine the coordinates based on remaining position
    long long x, y;
    if (remaining <= level)
    {
        x = remaining;
        y = level;
    }
    else if (remaining <= 2 * level)
    {
        x = level;
        y = 2 * level - remaining;
    }
    else if (remaining <= 3 * level)
    {
        x = 3 * level - remaining;
        y = -level;
    }
    else
    {
        x = -level;
        y = remaining - 4 * level;
    }

    return {x, y};
}

int main()
{
    int T;
    cin >> T; // Number of test cases

    while (T--)
    {
        long long N;
        cin >> N;
        pair<long long, long long> result = findCoordinates(N);
        cout << result.first << " " << result.second << endl;
    }

    return 0;
}
