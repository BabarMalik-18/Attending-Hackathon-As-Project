#include <iostream>
#include <vector>
#include <climits>
#include <algorithm>
using namespace std;

pair<int, int> computeDangerAndCost(const vector<int> &heights, int bridgeHeight)
{
    int danger = 0, cost = 0;
    for (int h : heights)
    {
        if (h < bridgeHeight)
        {
            danger += (bridgeHeight - h);
        }
        else if (h > bridgeHeight)
        {
            cost += (h - bridgeHeight);
        }
    }
    return {danger, cost};
}

int solveSingleTestCase(int B, const vector<int> &heights)
{
    int minDanger = INT_MAX;
    int optimalHeight = -1;

    int left = 0, right = *max_element(heights.begin(), heights.end());

    while (left <= right)
    {
        int mid = left + (right - left) / 2;

        // Compute the danger and cost for the current height (mid)
        pair<int, int> result = computeDangerAndCost(heights, mid);
        int danger = result.first; // Extract danger from the pair
        int cost = result.second;  // Extract cost from the pair

        if (cost <= B)
        {
            // If cost is within budget, check if this height minimizes the danger
            if (danger < minDanger)
            {
                minDanger = danger;
                optimalHeight = mid;
            }
            // Try for a higher height (since we want the minimum danger)
            left = mid + 1;
        }
        else
        {
            // If cost exceeds B, reduce the bridge height
            right = mid - 1;
        }
    }

    return optimalHeight;
}

int main()
{
    int T;
    cin >> T;
    while (T--)
    {
        int B, N;
        cin >> B >> N;
        vector<int> heights(N);
        for (int i = 0; i < N; ++i)
        {
            cin >> heights[i];
        }
        cout << solveSingleTestCase(B, heights) << endl;
    }
    return 0;
}
