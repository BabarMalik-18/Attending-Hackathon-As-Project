from collections import deque

def min_actions_to_reach_end(grid, N, M, K, start, end):
    # Directions for walking and dashing: (dx, dy)
    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    
    # Initialize the queue with the starting position, number of actions, and hair color (True = red, False = blue)
    queue = deque([(start[0], start[1], 0, True)])
    
    # Visited state: (x, y, hair color)
    visited = set()
    visited.add((start[0], start[1], True))
    
    while queue:
        x, y, actions, can_dash = queue.popleft()
        
        # Check if we've reached the end
        if (x, y) == end:
            return actions
        
        # Try to walk in each direction
        for dx, dy in directions:
            nx, ny = x + dx, y + dy
            if 0 <= nx < N and 0 <= ny < M and grid[nx][ny] != '#' and (nx, ny, can_dash) not in visited:
                visited.add((nx, ny, can_dash))
                queue.append((nx, ny, actions + 1, can_dash))
        
        # Try to dash if hair is red
        if can_dash:
            for dx, dy in directions:
                for step in range(1, K + 1):
                    nx, ny = x + dx * step, y + dy * step
                    if not (0 <= nx < N and 0 <= ny < M) or grid[nx][ny] == '#':
                        break
                    # Refresh dash if crossing a crystal
                    dash_refresh = grid[nx][ny] == '*'
                    if (nx, ny, dash_refresh) not in visited:
                        visited.add((nx, ny, dash_refresh))
                        queue.append((nx, ny, actions + 1, dash_refresh))
    
    return -1  # If no path to end is found

# Read input
T = int(input())
for _ in range(T):
    N, M, K = map(int, input().split())
    grid = [input().strip() for _ in range(N)]
    
    # Find start (S) and end (E) positions
    start = end = None
    for i in range(N):
        for j in range(M):
            if grid[i][j] == 'S':
                start = (i, j)
            elif grid[i][j] == 'E':
                end = (i, j)
    
    # Solve for the current test case
    result = min_actions_to_reach_end(grid, N, M, K, start, end)
    print(result)
