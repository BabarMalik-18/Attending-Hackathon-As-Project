#include <iostream>
#include <string>
using namespace std;

int main() {
    int T;
    cin >> T;
    while (T--) {
        string S;
        cin >> S;
        for (char c : S) {
            if (c == 'O') {
                cout << "[###OREO###]" << endl;
            } else if (c == 'R') {
                cout << "[--------]" << endl;
            } else if (c == '&') {
                cout << endl;
            }
        }
    }
    return 0;
}
