#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <algorithm>
#include <cmath>
using namespace std;

class SegmentTree
{
private:
    vector<long long> tree, lazy;
    int size;

    void build(const vector<long long> &arr, int node, int start, int end)
    {
        if (start == end)
        {
            tree[node] = arr[start];
        }
        else
        {
            int mid = (start + end) / 2;
            build(arr, 2 * node, start, mid);
            build(arr, 2 * node + 1, mid + 1, end);
            tree[node] = tree[2 * node] + tree[2 * node + 1];
        }
    }

    void updateRange(int node, int start, int end, int l, int r, long long val)
    {
        if (lazy[node] != 0)
        {
            tree[node] += lazy[node] * (end - start + 1);
            if (start != end)
            {
                lazy[2 * node] += lazy[node];
                lazy[2 * node + 1] += lazy[node];
            }
            lazy[node] = 0;
        }

        if (start > r || end < l)
            return;

        if (start >= l && end <= r)
        {
            tree[node] += val * (end - start + 1);
            if (start != end)
            {
                lazy[2 * node] += val;
                lazy[2 * node + 1] += val;
            }
            return;
        }

        int mid = (start + end) / 2;
        updateRange(2 * node, start, mid, l, r, val);
        updateRange(2 * node + 1, mid + 1, end, l, r, val);
        tree[node] = tree[2 * node] + tree[2 * node + 1];
    }

    long long query(int node, int start, int end, int l, int r)
    {
        if (lazy[node] != 0)
        {
            tree[node] += lazy[node] * (end - start + 1);
            if (start != end)
            {
                lazy[2 * node] += lazy[node];
                lazy[2 * node + 1] += lazy[node];
            }
            lazy[node] = 0;
        }

        if (start > r || end < l)
            return 0;

        if (start >= l && end <= r)
            return tree[node];

        int mid = (start + end) / 2;
        long long left = query(2 * node, start, mid, l, r);
        long long right = query(2 * node + 1, mid + 1, end, l, r);
        return left + right;
    }

public:
    SegmentTree(const vector<long long> &arr)
    {
        size = arr.size();
        tree.resize(4 * size, 0);
        lazy.resize(4 * size, 0);
        build(arr, 1, 0, size - 1);
    }

    void update(int l, int r, long long val)
    {
        updateRange(1, 0, size - 1, l, r, val);
    }

    long long getValueAtIndex(int index)
    {
        return query(1, 0, size - 1, index, index);
    }

    long long sum()
    {
        return query(1, 0, size - 1, 0, size - 1);
    }
};

long long calculateMinSum(vector<long long> &arr)
{
    long long gcd = arr[0];
    for (auto num : arr)
        gcd = __gcd(gcd, num);
    long long minSum = 0;
    for (auto num : arr)
        minSum += num / gcd;
    return minSum;
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N;
    cin >> N;

    vector<long long> arr(N);
    for (int i = 0; i < N; ++i)
    {
        cin >> arr[i];
    }

    SegmentTree segTree(arr);

    int Q;
    cin >> Q;

    while (Q--)
    {
        string queryType;
        cin >> queryType;

        if (queryType == "UPDATE")
        {
            int L, R;
            long long V;
            cin >> L >> R >> V;
            segTree.update(L - 1, R - 1, V);
        }
        else if (queryType == "FIND")
        {
            vector<long long> updatedArr(N);
            for (int i = 0; i < N; ++i)
            {
                updatedArr[i] = segTree.getValueAtIndex(i);
            }
            cout << calculateMinSum(updatedArr) << '\n';
        }
    }

    return 0;
}
