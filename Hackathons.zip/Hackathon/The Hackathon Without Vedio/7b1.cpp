#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
using namespace std;

// Direction vectors for adjacency (up, down, left, right)
const int dx[] = {-1, 1, 0, 0};
const int dy[] = {0, 0, -1, 1};

struct Cell
{
    int height, x, y;
    bool operator<(const Cell &other) const
    {
        return height > other.height; // Sort by descending height
    }
};

// Union-Find Data Structure
class UnionFind
{
public:
    vector<int> parent, rank;
    int count;

    UnionFind(int n) : parent(n), rank(n, 0), count(0)
    {
        for (int i = 0; i < n; ++i)
            parent[i] = i;
    }

    int find(int x)
    {
        if (parent[x] != x)
        {
            parent[x] = find(parent[x]); // Path compression
        }
        return parent[x];
    }

    void unite(int x, int y)
    {
        int rootX = find(x);
        int rootY = find(y);
        if (rootX != rootY)
        {
            if (rank[rootX] > rank[rootY])
            {
                parent[rootY] = rootX;
            }
            else if (rank[rootX] < rank[rootY])
            {
                parent[rootX] = rootY;
            }
            else
            {
                parent[rootY] = rootX;
                rank[rootX]++;
            }
            count--; // Merging reduces the component count
        }
    }

    void addComponent()
    {
        count++;
    }

    int getCount()
    {
        return count;
    }
};

int maxIslands(vector<vector<int>> &grid)
{
    int n = grid.size();
    int m = grid[0].size();
    vector<Cell> cells;

    // Collect all cells with their heights and coordinates
    for (int i = 0; i < n; ++i)
    {
        for (int j = 0; j < m; ++j)
        {
            cells.push_back({grid[i][j], i, j});
        }
    }

    // Sort cells by height in descending order
    sort(cells.begin(), cells.end());

    UnionFind uf(n * m);
    vector<vector<bool>> visited(n, vector<bool>(m, false));
    int maxIslands = 0;

    // Process cells in descending order of height
    for (const auto &cell : cells)
    {
        int x = cell.x, y = cell.y;
        visited[x][y] = true;
        uf.addComponent();

        // Check all 4 neighbors
        for (int dir = 0; dir < 4; ++dir)
        {
            int nx = x + dx[dir];
            int ny = y + dy[dir];
            if (nx >= 0 && nx < n && ny >= 0 && ny < m && visited[nx][ny])
            {
                uf.unite(x * m + y, nx * m + ny);
            }
        }

        // Update the maximum number of islands
        maxIslands = max(maxIslands, uf.getCount());
    }

    return maxIslands;
}

int main()
{
    int T;
    cin >> T; // Number of test cases
    while (T--)
    {
        int N, M;
        cin >> N >> M;
        vector<vector<int>> grid(N, vector<int>(M));

        // Read the grid
        for (int i = 0; i < N; ++i)
        {
            for (int j = 0; j < M; ++j)
            {
                cin >> grid[i][j];
            }
        }

        // Output the maximum number of islands for this test case
        cout << maxIslands(grid) << endl;
    }
    return 0;
}
