#include <iostream>
#include <vector>
#include <queue>
#include <unordered_map>
#include <unordered_set>

using namespace std;

int main()
{
    int T;
    cin >> T; // Number of test cases

    for (int test = 0; test < T; ++test)
    {
        // BFS setup
        queue<int> q;
        unordered_map<int, vector<int>> graph;
        unordered_set<int> visited;
        unordered_map<int, int> distance;

        // Start BFS from vertex 1
        q.push(1);
        visited.insert(1);
        distance[1] = 0;

        bool found = false;

        while (!q.empty() && !found)
        {
            int current = q.front();
            q.pop();

            // Perform three SCAN operations to discover neighbors
            for (int i = 0; i < 3; ++i)
            {
                cout << "SCAN " << current << endl;
                cout.flush();

                int neighbor;
                cin >> neighbor;

                if (!visited.count(neighbor))
                {
                    graph[current].push_back(neighbor);
                    graph[neighbor].push_back(current);
                    visited.insert(neighbor);
                    q.push(neighbor);
                    distance[neighbor] = distance[current] + 1;

                    if (neighbor == 500)
                    {
                        found = true;
                        break;
                    }
                }
            }
        }

        // Submit the shortest path length to vertex 500
        cout << "SUBMIT " << distance[500] << endl;
        cout.flush();

        string response;
        cin >> response;
        if (response == "WRONG_ANSWER")
        {
            exit(0); // Exit if submission is incorrect
        }
    }

    return 0;
}
