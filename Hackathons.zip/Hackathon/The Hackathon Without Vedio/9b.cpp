#include <iostream>
#include <vector>
#include <queue>
#include <unordered_set>
#include <limits.h>

using namespace std;

// Function to simulate scanning a vertex
int scanVertex(int v)
{
    cout << "SCAN " << v << endl;
    int neighbor;
    cin >> neighbor;
    return neighbor;
}

// BFS to find the shortest path length
int findShortestPath()
{
    // Start BFS from vertex 1
    queue<int> q;
    unordered_set<int> visited;
    q.push(1);
    visited.insert(1);

    int distance = 0;

    while (!q.empty())
    {
        int size = q.size();
        for (int i = 0; i < size; i++)
        {
            int current = q.front();
            q.pop();

            // If we reach vertex 500, return the distance
            if (current == 500)
            {
                return distance;
            }

            // Scan current vertex to get a neighbor
            for (int j = 0; j < 3; j++)
            { // Each vertex has 3 neighbors
                int neighbor = scanVertex(current);
                if (visited.find(neighbor) == visited.end())
                {
                    visited.insert(neighbor);
                    q.push(neighbor);
                }
            }
        }
        distance++;
    }

    return -1; // Should not reach here in a connected graph
}

int main()
{
    int T;
    cin >> T; // Number of test cases

    for (int i = 0; i < T; i++)
    {
        int shortestPath = findShortestPath();
        cout << "SUBMIT " << shortestPath << endl;
        string response;
        cin >> response;

        if (response == "WRONG_ANSWER")
        {
            exit(0);
        }
    }

    return 0;
}
