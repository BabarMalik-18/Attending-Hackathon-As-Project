#include <iostream>
#include <vector>
#include <climits> // For INT_MAX
using namespace std;

int main()
{
    int T;
    cin >> T;
    while (T--)
    {
        int B, N;
        cin >> B >> N;
        vector<int> heights(N);
        for (int i = 0; i < N; i++)
            cin >> heights[i];

        int minDanger = INT_MAX, bestHeight = 0;

        for (int h = 0; h <= 100; h++)
        {
            int cost = 0, danger = 0;

            for (int building : heights)
            {
                if (building > h)
                    cost += building - h;
                else
                    danger += h - building;
            }

            if (cost <= B)
            {
                if (danger < minDanger || (danger == minDanger && h < bestHeight))
                {
                    minDanger = danger;
                    bestHeight = h;
                }
            }
        }

        cout << bestHeight << endl;
    }

    return 0;
}
