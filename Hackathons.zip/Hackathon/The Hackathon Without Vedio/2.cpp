#include <iostream>
#include <vector>
#include <unordered_map>
#include <algorithm>

using namespace std;

int minSetsOfBlocks(const string &s)
{
    unordered_map<char, int> blockCount;
    for (char c : s)
    {
        blockCount[c]++;
    }

    // Each set of CALICO blocks contains one of each letter
    unordered_map<char, int> calicoBlocks = {
        {'A', 1}, {'B', 1}, {'C', 1}, {'D', 1}, {'E', 1}, {'F', 1}, {'G', 1}, {'H', 1}, {'I', 1}, {'J', 1}, {'K', 1}, {'L', 1}, {'M', 1}, {'N', 1}, {'O', 1}, {'P', 1}, {'Q', 1}, {'R', 1}, {'S', 1}, {'T', 1}, {'U', 1}, {'V', 1}, {'W', 1}, {'X', 1}, {'Y', 1}, {'Z', 1}};

    int sets = 0;
    for (auto &pair : blockCount)
    {
        char letter = pair.first;
        int required = pair.second;

        if (calicoBlocks.find(letter) == calicoBlocks.end())
        {
            return -1; // If the letter is not in CALICO blocks, return -1
        }

        int available = calicoBlocks[letter];
        sets = max(sets, (required + available - 1) / available);
    }

    return sets;
}

int main()
{
    int T;
    cin >> T;
    vector<string> testCases(T);
    for (int i = 0; i < T; ++i)
    {
        cin >> testCases[i];
    }

    for (const string &s : testCases)
    {
        cout << minSetsOfBlocks(s) << endl;
    }

    return 0;
}
