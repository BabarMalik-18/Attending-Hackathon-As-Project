#include <iostream>
#include <vector>
#include <queue>
#include <set>
#include <algorithm>
using namespace std;

// Directions for moving up, down, left, and right
const int dx[4] = {-1, 1, 0, 0};
const int dy[4] = {0, 0, -1, 1};

// Function to perform BFS and mark the connected cells of an island
void bfs(int x, int y, int h, vector<vector<int>> &grid, vector<vector<bool>> &visited)
{
    int n = grid.size();
    int m = grid[0].size();
    queue<pair<int, int>> q;
    q.push({x, y});
    visited[x][y] = true;

    while (!q.empty())
    {
        auto [cx, cy] = q.front();
        q.pop();

        for (int dir = 0; dir < 4; dir++)
        {
            int nx = cx + dx[dir];
            int ny = cy + dy[dir];

            if (nx >= 0 && nx < n && ny >= 0 && ny < m && !visited[nx][ny] && grid[nx][ny] >= h)
            {
                visited[nx][ny] = true;
                q.push({nx, ny});
            }
        }
    }
}

int countIslands(int h, vector<vector<int>> &grid)
{
    int n = grid.size();
    int m = grid[0].size();
    vector<vector<bool>> visited(n, vector<bool>(m, false));
    int islandCount = 0;

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            if (!visited[i][j] && grid[i][j] >= h)
            {
                islandCount++;
                bfs(i, j, h, grid, visited);
            }
        }
    }

    return islandCount;
}

int main()
{
    int T;
    cin >> T;
    while (T--)
    {
        int N, M;
        cin >> N >> M;
        vector<vector<int>> grid(N, vector<int>(M));

        for (int i = 0; i < N; i++)
        {
            for (int j = 0; j < M; j++)
            {
                cin >> grid[i][j];
            }
        }

        int maxIslands = 0;
        for (int h = 0; h <= 100; h++)
        {
            maxIslands = max(maxIslands, countIslands(h, grid));
        }

        cout << maxIslands << endl;
    }

    return 0;
}
