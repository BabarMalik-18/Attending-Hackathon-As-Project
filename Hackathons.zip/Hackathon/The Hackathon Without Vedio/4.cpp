#include <iostream>
#include <vector>
#include <iomanip>
#include <algorithm>

using namespace std;

double minTimeToExitStorm(int N, int H, int D, int S, int P)
{
    // If running directly to the exit is possible
    double timeToExit = static_cast<double>(D) / S;
    double healthAfterRun = N - timeToExit * P;
    if (healthAfterRun >= 0)
    {
        return timeToExit;
    }

    // If healing is required
    double low = 0.0, high = 1e9;
    while (high - low > 1e-7)
    {
        double mid = (low + high) / 2;
        double timeRunning = mid;
        double timeHealing = (mid * P - N) / (H + P);
        if (timeHealing < 0)
        {
            timeHealing = 0;
        }
        if (timeRunning * S >= D && timeRunning + timeHealing <= mid)
        {
            high = mid;
        }
        else
        {
            low = mid;
        }
    }

    double result = (low + high) / 2;
    if (result > 1e8)
    {
        return -1.0;
    }
    return result;
}

int main()
{
    int T;
    cin >> T;
    vector<double> results;
    for (int i = 0; i < T; ++i)
    {
        int N, H, D, S, P;
        cin >> N >> H >> D >> S >> P;
        results.push_back(minTimeToExitStorm(N, H, D, S, P));
    }

    cout << fixed << setprecision(6);
    for (double result : results)
    {
        cout << result << endl;
    }

    return 0;
}
